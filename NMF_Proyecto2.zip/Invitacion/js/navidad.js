function choice1(select) {
  alert(select.options[select.selectedIndex].text);
}
/*let go = "no";
if (go === "yes") {
    alert("Wuuuu");
  } else {
    alert("😔");
  }
*/
